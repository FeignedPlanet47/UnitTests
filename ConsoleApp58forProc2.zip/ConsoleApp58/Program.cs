﻿using System;
using System.Collections.Generic;

namespace OOPProject
{
    public class Beverage
    {
        public string Type { get; set; }
        public double Price { get; set; }

        public Beverage(string type, double price)
        {
            Type = type;
            Price = price;
        }
    }

    public class Coffee : Beverage
    {
        public int Size { get; set; }
        public bool HasMilk { get; set; }
        public bool HasSugar { get; set; }

        public Coffee(string type, int size, bool hasMilk, bool hasSugar, double price) : base(type, price)
        {
            Size = size;
            HasMilk = hasMilk;
            HasSugar = hasSugar;
        }
    }

    public class Customer
    {
        public string Name { get; set; }
        public string Email { get; set; }

        public Customer(string name, string email)
        {
            Name = name;
            Email = email;
        }

        public void DisplayCustomerInfo()
        {
            Console.WriteLine($"Customer Name: {Name}, Email: {Email}");
        }
    }

    public class CoffeeMenu
    {
        private Dictionary<string, Beverage> menuItems;

        public CoffeeMenu()
        {
            menuItems = new Dictionary<string, Beverage>();
            menuItems.Add("Эспрессо", new Beverage("Эспрессо", 2.5));
            menuItems.Add("Латте", new Beverage("Латте", 3.0));
            menuItems.Add("Капучино", new Beverage("Капучино", 3.5));
        }

        public void DisplayMenu()
        {
            Console.WriteLine("Coffee Menu:");
            foreach (var item in menuItems)
            {
                Console.WriteLine($"{item.Key}: ${item.Value.Price}");
            }
        }

        public double GetPrice(string coffeeType)
        {
            if (menuItems.ContainsKey(coffeeType))
            {
                return menuItems[coffeeType].Price;
            }
            else
            {
                Console.WriteLine($"Coffee type '{coffeeType}' not found in the menu.");
                return 0.0;
            }
        }
    }

    public class CoffeeShop
    {
        private List<Coffee> coffeeOrders;
        private CoffeeMenu menu;
        private Customer customer;

        public CoffeeShop(Customer customer)
        {
            this.customer = customer;
            coffeeOrders = new List<Coffee>();
            menu = new CoffeeMenu();
        }

        public void PlaceOrder(string coffeeType, int size, bool hasMilk, bool hasSugar)
        {
            if (menu.GetPrice(coffeeType) > 0)
            {
                Coffee coffee = new Coffee(coffeeType, size, hasMilk, hasSugar, menu.GetPrice(coffeeType));
                coffeeOrders.Add(coffee);
                Console.WriteLine($"Order placed: {coffeeType} coffee, Size: {size}, Milk: {hasMilk}, Sugar: {hasSugar}");
            }
            else
            {
                Console.WriteLine($"Sorry, {coffeeType} is not available.");
            }
        }

        public double CalculateTotalRevenue()
        {
            double totalRevenue = 0;
            foreach (var coffee in coffeeOrders)
            {
                totalRevenue += coffee.Price;
            }
            return totalRevenue;
        }

        public int GetTotalOrders()
        {
            return coffeeOrders.Count;
        }

        public List<string> GetOrderSummaries()
        {
            List<string> orderSummaries = new List<string>();
            foreach (var coffee in coffeeOrders)
            {
                orderSummaries.Add(coffee.Type);
            }
            return orderSummaries;
        }

        public void ClearOrders()
        {
            coffeeOrders.Clear();
        }

        public Coffee GetLastOrder()
        {
            if (coffeeOrders.Count == 0)
            {
                Console.WriteLine("No orders placed yet");
                return null;
            }
            return coffeeOrders[coffeeOrders.Count - 1];
        }
    }

    public class Program
    {
        public static void Main(string[] args)
        {
            Customer customer = new Customer("John Doe", "john@example.com");
            CoffeeShop coffeeShop = new CoffeeShop(customer);

            coffeeShop.PlaceOrder("Эспрессо", 2, true, true);
            coffeeShop.PlaceOrder("Латте", 2, true, true);

            Console.WriteLine($"Total orders: {coffeeShop.GetTotalOrders()}");
            Console.WriteLine($"Total revenue: ${coffeeShop.CalculateTotalRevenue()}");

            List<string> orderSummaries = coffeeShop.GetOrderSummaries();
            Console.WriteLine("Order summaries:");
            foreach (var summary in orderSummaries)
            {
                Console.WriteLine(summary);
            }

            coffeeShop.ClearOrders();
        }
    }
}
