﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OOPProject;
namespace UnitTestProject2
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Coffee coffee = new Coffee("Латте", 2, false, true);
            double excpectedPrice = 3.25;
            double realPrice = coffee.CalculatePrice(coffee.Size, coffee.HasMilk, coffee.HasSugar);
            Assert.AreEqual(excpectedPrice, realPrice);
        }
        [TestMethod]
        public void TestMethod2()
        {
            CoffeeShop coffeeShop = new CoffeeShop();
            List<Coffee> coffees = new List<Coffee>
            {
                new Coffee("Эспрессо", 2, true, true),
                new Coffee("Латте", 1, true, true)
            };

            List<string> expectedOrderSummaries = new List<string>
            {
                "Coffee: Эспрессо, Size: 2, Milk: Yes, Sugar: Yes",
                "Coffee: Латте, Size: 1, Milk: Yes, Sugar: Yes"
            };
            List<string> realOrderSummaries = coffeeShop.GetOrderSummaries(coffees);
            CollectionAssert.AreEqual(expectedOrderSummaries, realOrderSummaries);
        }
        [TestMethod]
        public void TestMethod3()
        {
            CoffeeShop coffeeShop = new CoffeeShop();
            List<Coffee> coffees = new List<Coffee>
            {
                new Coffee("Эспрессо", 2, true, true),
                new Coffee("Латте", 2, true, true)
            };
            double excpectedResult = 7.5;
            double realResult = coffeeShop.CalculateTotalRevenue(coffees);
            Assert.AreEqual(excpectedResult, realResult);
        }
        [TestMethod]
        public void TestMethod4()
        {
            CoffeeShop coffeeShop = new CoffeeShop();
            List<Coffee> coffees = new List<Coffee>
            {
                new Coffee("Эспрессо", 2, true, true),
                new Coffee("Латте", 2, true, true)
            };
            Coffee excpectedCoffee = new Coffee("Латте", 2, true, true);
            Coffee realCoffee = coffeeShop.GetLastOrder(coffees);
            CollectionAssert.Equals(excpectedCoffee, realCoffee);
        }
        [TestMethod]
        public void TestMethod5()
        {
            CoffeeShop coffeeShop = new CoffeeShop();
            List<Coffee> coffees = new List<Coffee>
            {
                new Coffee("Эспрессо", 2, true, true),
                new Coffee("Латте", 2, true, true)
            };
            int excpectedResult = 2;
            int realResult = coffeeShop.GetTotalOrders(coffees);
            CollectionAssert.Equals(excpectedResult, realResult);
        }
    }
}
