﻿using System.Collections.Generic;
using System;

namespace OOPProject
{
    public class Coffee
    {
        public string Type { get; set; }
        public int Size { get; set; }
        public bool HasMilk { get; set; }
        public bool HasSugar { get; set; }
        public Coffee(string type, int size, bool hasMilk, bool hasSugar)
        {
            Type = type;
            Size = size;
            HasMilk = hasMilk;
            HasSugar = hasSugar;
        }
        public double CalculatePrice(int size, bool hasMilk, bool hasSugar)
        {
            double price = 2.0;

            if (Size == 1)
            {
                price += 0.5;
            }
            else if (Size == 2)
            {
                price += 1.0;
            }

            if (HasMilk)
            {
                price += 0.5;
            }
            if (HasSugar)
            {
                price += 0.25;
            }

            return price;
        }

        public string GetOrderSummary()
        {
            string summary = $"Coffee: {Type}, Size: {Size}, Milk: {(HasMilk ? "Yes" : "No")}, Sugar: {(HasSugar ? "Yes" : "No")}";
            return summary;
        }
    }

    public class CoffeeShop
    {
        public List<Coffee> coffeeOrders;

        public CoffeeShop()
        {
            coffeeOrders = new List<Coffee>();
        }

        public void PlaceOrder(Coffee coffee)
        {
            coffeeOrders.Add(coffee);
            Console.WriteLine("Order placed: {0} coffee, Size: {1}, Milk: {2}, Sugar: {3}",
            coffee.Type, coffee.Size, coffee.HasMilk, coffee.HasSugar);
        }

        public double CalculateTotalRevenue(List<Coffee> coffeeOrder)
        {
            double totalRevenue = 0;
            foreach (var coffee in coffeeOrder)
            {
                totalRevenue += coffee.CalculatePrice(coffee.Size, coffee.HasMilk, coffee.HasSugar);
            }
            return totalRevenue;
        }

        public int GetTotalOrders(List<Coffee> coffees)
        {
            return coffees.Count;
        }

        public List<string> GetOrderSummaries(List<Coffee> coffeeOrders)
        {
            List<string> orderSummaries = new List<string>();
            foreach (var coffee in coffeeOrders)
            {
                orderSummaries.Add(coffee.GetOrderSummary());
            }
            return orderSummaries;
        }

        public void ClearOrders()
        {
            coffeeOrders.Clear();
        }

        public Coffee GetLastOrder(List<Coffee> coffeeOrder)
        {
            if (coffeeOrder.Count == 0)
            {
                Console.WriteLine("No orders placed yet");
            }
            return coffeeOrder[coffeeOrder.Count - 1];
        }
        public static void Main(string[] args)
        {
            CoffeeShop coffeeShop = new CoffeeShop();
            List<Coffee> coffees = new List<Coffee>
            {
                new Coffee("Эспрессо", 2, true, true),
                new Coffee("Латте", 2, true, true)
            };
            Coffee excpectedCoffee = new Coffee("Латте", 2, true, true);
            Coffee realCoffee = coffeeShop.GetLastOrder(coffees);
           
            coffeeShop.PlaceOrder(excpectedCoffee);
            coffeeShop.PlaceOrder(realCoffee);
        }
    }

}

